﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DancerRemote
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditorPage
    {
        private string _songFilePath;
        private string _fromMessage = string.Empty;

        public EditorPage()
        {
            InitializeComponent();
            BindingContext = this;
            MessagingCenter.Subscribe<string, string>("SongFilePath", "SongFilePathMessage",
                (s, args) => { _fromMessage = args; });
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (!string.IsNullOrEmpty(_fromMessage))
            {
                SongFilePath = _fromMessage;
            }
        }

        public string SongFilePath
        {
            get => _songFilePath;
            set
            {
                _songFilePath = value;
                OnPropertyChanged();
            }
        }

        private async void ImageButton_OnClicked(object sender, EventArgs e)
        {
            await this.Navigation.PushAsync(new SongsPage());
        }
    }
}