﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace DancerRemote
{
    public class WaveView : View
    {
        public static readonly BindableProperty SongPathProperty =
            BindableProperty.Create(nameof(SongPath), typeof(string), typeof(WaveView), string.Empty);

        public string SongPath
        {
            get => (string) GetValue(SongPathProperty);
            set => SetValue(SongPathProperty, value);
        }
    }
}
