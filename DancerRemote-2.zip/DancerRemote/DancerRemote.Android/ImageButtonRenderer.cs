﻿using Android.Content;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using ImageButton = Xamarin.Forms.ImageButton;
using ImageButtonRenderer = DancerRemote.Droid.ImageButtonRenderer;

//[assembly:ExportRenderer(typeof(ImageButton), typeof(ImageButtonRenderer))]
namespace DancerRemote.Droid
{
    public class ImageButtonRenderer : Xamarin.Forms.Platform.Android.ImageButtonRenderer
    {
        public ImageButtonRenderer(Context context) : base(context)
        {

        }

        protected override void OnElementChanged(ElementChangedEventArgs<ImageButton> e)
        {
            base.OnElementChanged(e);
           // if(Element.)
        }
    }
}